/*
 * String Length
 */

#include <stdio.h>
#include <string.h>

int main(void) {
  int len;

  /* len is now 3 */
  len = strlen("abc");
  printf("String Length = %d\n",len);

  /* len is now 0 */
  len = strlen("");
  printf("String Length = %d\n",len);

  return 0;
}
