/*
 * Planet Array Size #2
 */

#include <stdio.h>

int main(void) {
  char *planets[] = {"Mercury","Venus","Earth","Mars","Jupiter","Saturn","Uranus","Neptune","Pluto"};

for (int i = 0; i < 9; i++) {
  printf(" %7s : %d\n",planets[i],strlen(planets[i]));
}
  return 0;
}
