/*
 * Planet Array Size
 */

#include <stdio.h>
#include <string.h>

int main(void) {
  char planets[][3][8] =
{"Mercury",
 "Venus  ",
 "Earth  ",
 "Mars   ",
 "Jupiter",
 "Saturn ",
 "Uranus ",
 "Neptune",
 "Pluto  "};

  for (int i=0; i < 3; i++) {
      for (int j=0; j < 3; j++) {
           printf(" %7s : %d\n",planets[i][j],strlen(planets[i][j]));
        }
    printf("\n");
  }
  return 0;
}
