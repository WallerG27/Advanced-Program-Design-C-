/*
 * strcpy
 */

#include <stdio.h>
#include <string.h>

int main(void) {

  char str1[20], str2[20];

  /* str2 now contains "abcd" */
  strcpy(str2, "abcd");
  printf("str2 = %s\n",str2);

  /* str1 now contains "abcd" */
  strcpy(str1, str2);
  printf("str1 = %s\n",str1);


  return 0;
}
