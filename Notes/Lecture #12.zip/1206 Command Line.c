/*
 * Command Line
 */

#include <stdio.h>

int main(int argc, char *argv[]) {

  int i;

  printf("\n# of command line arguments: %d\n",argc);
  printf("\n");
  printf("program name: %s\n\n",argv[0]);
  printf("\n");

	for (i = 0; i < argc; i++)
	  printf("argv[%d] %s\n", i,argv[i]);

  return 0;
}
