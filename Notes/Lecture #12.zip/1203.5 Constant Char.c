/*
 * Constant Char
 */

#include <stdio.h>


size_t stringLength(const char* string) {
    size_t length = 0;
    *string = 'A';
    while(*(string++)) {
        length++;
    }
    return length;
}

int main(void) {
    char myString[10];
    stringLength(myString);
    return 0;
}
