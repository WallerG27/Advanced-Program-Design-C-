/*
 * Add
 */

#include <stdio.h>

#define N 5

int main(void) {
  int a[] = {1,1,1,1,1};
  int sum = 0;
  int *p;

  for (p = &a[0]; p < &a[N]; p++)
	  sum += *p;

  printf("sum = %d\n",sum);

  sum = 0;
  p = a;
	while (p < &a[N])
	  sum += *(p++);

  printf("sum = %d\n",sum);

  return 0;
}