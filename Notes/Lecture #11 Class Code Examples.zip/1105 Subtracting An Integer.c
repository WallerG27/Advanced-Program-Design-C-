/*
 * Subtracting An Integer from a
 * Pointer
 */

#include <stdio.h>

int main(void) {

  int a[] = {1,2,3,4,5,6,7,8,9,10};
  int *p;
  int *q;
  int i;

  p = &a[8];
  printf("p = %d\n",*p);

  q = p - 3;
  printf("q = %d\n",*q);

  p -= 6;
  printf("p = %d\n",*p);

  return 0;
}
