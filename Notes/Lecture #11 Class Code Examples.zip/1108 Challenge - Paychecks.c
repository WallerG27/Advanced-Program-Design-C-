/*
 * Challenge - Paychecks
 */

#include <stdio.h>

int main(void) {

  int workHours[] = 
{4,6,3,7,2,5,8,4,6,5,7,3,7,3,7,6,8,5,3,6};
  int requestDays[] =            
        {4,7,9,13,17,19};

  int *request = &requestDays;

  for (int i=0; i < 6; i++) {
    request = &requestDays[i];
    printf("On day %d, you worked %d hours\n",requestDays[i],workHours[*request]);
  }
  return 0;
}