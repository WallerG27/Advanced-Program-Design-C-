/*
 * Combining
 */

#include <stdio.h>

int main(void) {
  int a [] = {1,2,3,4,5};

  for(int i=0; i<5;)
    printf("%d\n",a[i++]);
  return 0;
}