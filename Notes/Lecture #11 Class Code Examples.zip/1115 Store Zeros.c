/*
 * Store Zeros
 */

#include <stdio.h>

void store_zeros(int a[], int n)
	{
	  int *p;

	  for (p = a; p < a+n; p++)
	    *p= 0;
	}


int main(void) {
  int myArray[] = {1,2,3,4,5};

  for (int i=0; i< 5; i++)
    printf("%d ",myArray[i]);
  printf("\n");

  store_zeros(myArray,5);
  for (int i=0; i< 5; i++)
    printf("%d ",myArray[i]);
  printf("\n");

  return 0;
}
