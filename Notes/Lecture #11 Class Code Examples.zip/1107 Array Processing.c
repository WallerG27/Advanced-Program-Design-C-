/*
 * Array Processing
 */

#include <stdio.h>

int main(void) {
  #define N 10
  int a[N] = {1,1,1,1,1,1,1,1,1,1},*p;
  int sum = 0;

  for (p = &a[0]; p < &a[N]; p++)
	  sum += *p;

  printf("sum = %d\n",sum);

  return 0;
}
