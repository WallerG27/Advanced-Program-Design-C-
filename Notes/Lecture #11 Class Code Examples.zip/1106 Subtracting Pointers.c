/*
 * Subtracting Pointers
 */

#include <stdio.h>

  int main(void) {

  int a[] = {1,2,3,4,5,6,7,8,9,10};
  int *p;
  int *q;
  int *z;

  p = &a[5];
  q = &a[1];
  printf("p = %d\n",*p);
  printf("q = %d\n",*q);

  z = p - q;
  printf("address z = %p\n",z);

  z = q - p;
  printf("address z = %p\n",z);

  return 0;
}
