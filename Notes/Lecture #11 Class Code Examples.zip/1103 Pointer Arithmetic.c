/*
 * Pointer Arithmetic
 */

#include <stdio.h>

int main(void) {
  int a[10];
  int *p;

  a[0] = -9;
  p = &a[0];
  printf("*p = %d\n",*p);

  *p = 5;
  printf("a[0] = %d\n",a[0]);
  return 0;
}
