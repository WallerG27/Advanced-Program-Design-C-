/*
 * Combining #2
 */


#include <stdio.h>

int main(void) {
  int a [] = {1,2,3,4,5};
  int i=0;
  int *p = &i;
 
  for(; i<5;)
    printf("%d\n",a[(*p)++]);

  return 0;
}