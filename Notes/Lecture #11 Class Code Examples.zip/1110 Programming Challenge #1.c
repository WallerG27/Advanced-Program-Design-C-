/*
 * Programming Challenge #1
 */

#include <stdio.h>

#define N 10

int main(void) {
  int testScores[] = {91,76,82,87,72,95,80,77,92,85};

  int *testPtr;
  int sum = 0;

  for ( testPtr = &testScores[0]; testPtr < &testScores[N]; testPtr++) {
    sum += *testPtr;
  }

  printf("Average = %d\n",sum/N);

  
  return 0;
}