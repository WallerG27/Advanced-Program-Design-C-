/*
 * Programming Challenge #2
 */

#include <stdio.h>

int main(void) {
  float chkAcct[] = {120.0, 560.0, -40.0, 1432.0, 6.0};
  float *chkAcctPtr;

  int amount = 1e6;
  printf("amount = %d\n",amount);

  amount = amount / 5;
  printf("New amount = %d\n",amount);

  printf("Before:\n");
  for (int i=0; i<5; i++) {
    printf("%f\n",chkAcct[i]);
  }

  
  for (chkAcctPtr = &chkAcct[0]; chkAcctPtr < chkAcct + 5; chkAcctPtr++) {
    *chkAcctPtr = *chkAcctPtr + (float)amount;
  }

  printf("\nAfter:\n");
  for (int i=0; i<5; i++) {
    printf("%f\n",chkAcct[i]);
  }
  
  return 0;
}