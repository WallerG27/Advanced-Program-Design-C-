/*
 * Decompose
 */


#include <stdio.h>

void decompose(double x,
               int *int_part,
               double *frac_part)
	{
	  *int_part = (int) x;
	  *frac_part = x - *int_part;

      printf("*int_part = %d\n",*int_part);
      printf("*frac_part = %f\n",*frac_part);
	}


int main(void) {
  int i;
  double d;

  decompose(3.14159, &i, &d);

  printf("\ni = %d\n",i);
  printf("d = %f\n",d);
  return 0;
}
