/*
 * Programming Challenge #3
 */

#include <stdio.h>

float classAverage (int *k,int *j,int *a) {
  float avg = 0.0;
  for (int i=0; i<4;i++) {
    printf("%d %d %d\n",*(k+i),*(j+i),*(a+i));
    avg += *(k+i)+*(j+i)+*(a+i);
    printf("sum = %f\n",avg);
  }
  avg = avg / 12;

  return(avg);
}

int main(void) {
  int kenScores[]  = {80, 92, 85, 87};
  int johnScores[] = {72, 78, 80, 86};
  int annScores[]  = {96, 92, 87, 90};

  float average;
  
  average = classAverage(kenScores,johnScores,annScores);

  printf("average = %f\n",average);
  
    return 0;
}